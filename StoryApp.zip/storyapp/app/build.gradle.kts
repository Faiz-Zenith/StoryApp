plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.jetbrains.kotlin.android)
    id("kotlin-kapt") // Diperlukan untuk Retrofit dan Gson
}

android {
    namespace = "com.muhammadiyah.storyapp"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.muhammadiyah.storyapp"
        minSdk = 21
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_1_8
        targetCompatibility = JavaVersion.VERSION_1_8
    }
    kotlinOptions {
        jvmTarget = "1.8"
    }
    viewBinding{
        enable = true
    }
}

dependencies {

    // AndroidX Core Libraries
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.appcompat)
    implementation(libs.material)
    implementation(libs.androidx.activity)
    implementation(libs.androidx.constraintlayout)

    // Testing Libraries
    testImplementation(libs.junit)
    androidTestImplementation(libs.androidx.junit)
    androidTestImplementation(libs.androidx.espresso.core)

    // Retrofit for API
    implementation(libs.retrofit)
    implementation(libs.retrofit2.converter.gson) // Gson converter

    // OkHttp for logging (debugging API calls)
    implementation(libs.logging.interceptor)

    // Glide for image loading
    implementation(libs.glide)
    kapt(libs.compiler)

    // Coroutine Support
    implementation(libs.kotlinx.coroutines.android)

    // Lifecycle Components
    implementation(libs.androidx.lifecycle.livedata.ktx)
    implementation(libs.lifecycle.viewmodel.ktx)

    // Preferences DataStore (untuk penyimpanan token)
    implementation(libs.androidx.datastore.preferences)
}