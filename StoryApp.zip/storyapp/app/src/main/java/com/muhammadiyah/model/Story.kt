package com.muhammadiyah.model

data class Story(
    val name: String,
    val description: String
)
