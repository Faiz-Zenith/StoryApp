package com.muhammadiyah.storyapp

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import com.muhammadiyah.api.ApiConfig
import com.muhammadiyah.storyapp.databinding.ActivityLoginBinding
import kotlinx.coroutines.runBlocking

class LoginActivity : AppCompatActivity() {
    private lateinit var binding: ActivityLoginBinding
    private lateinit var viewModel: LoginViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        Log.d("LoginActivity", "onCreate called")

        val userPreference = UserPreference.getInstance(applicationContext)
        val repository = StoryRepository(ApiConfig.getApiService(), userPreference)
        viewModel = ViewModelProvider(this, ViewModelFactory(repository))[LoginViewModel::class.java]

        viewModel.loginResult.observe(this) { loginResult ->
            Log.d("LoginActivity", "Login result: ${loginResult.token}")
            val token = loginResult.token ?: ""
            runBlocking {
                userPreference.saveUser(User(token))
            }

            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
            finish()
        }

        viewModel.errorMessage.observe(this) { error ->
            Log.d("LoginActivity", "Error: $error") // Debug log
            Toast.makeText(this, error, Toast.LENGTH_SHORT).show()
        }

        binding.buttonLogin.setOnClickListener {
            val email = binding.edLoginEmail.text.toString()
            val password = binding.edLoginPassword.getText()

            if (email.isNotEmpty() && password.isNotEmpty()) {
                Log.d("LoginActivity", "Logging in with email: $email") // Debug log
                viewModel.login(email, password)
            } else {
                Toast.makeText(this, "Email dan password tidak boleh kosong", Toast.LENGTH_SHORT).show()
            }
        }

        binding.tvSignupLink.setOnClickListener {
            val intent = Intent(this, SignupActivity::class.java)
            startActivity(intent)
        }
    }
}
