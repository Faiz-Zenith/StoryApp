package com.muhammadiyah.storyapp

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.launch

class LoginViewModel(private val repository: StoryRepository) : ViewModel() {
    private val _loginResult = MutableLiveData<LoginResult>()
    val loginResult: LiveData<LoginResult> = _loginResult

    private val _errorMessage = MutableLiveData<String>()
    val errorMessage: LiveData<String> = _errorMessage

    fun login(email: String, password: String) {
        viewModelScope.launch {
            try {
                val response = repository.login(email, password)

                if (response.error == false) {
                    response.loginResult?.let {
                        _loginResult.postValue(it)
                        Log.d("LoginViewModel", "Login Success: ${response.loginResult}")
                    }
                } else {
                    _errorMessage.postValue(response.message ?: "Login gagal")
                    Log.e("LoginViewModel", "Login Failed: ${response.message ?: "Login gagal"}")
                }
            } catch (e: Exception) {
                Log.e("LoginViewModel", "Login error: ${e.message}")
                _errorMessage.postValue(e.message ?: "Terjadi kesalahan")
            }
        }
    }
}
