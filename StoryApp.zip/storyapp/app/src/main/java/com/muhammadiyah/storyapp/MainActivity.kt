package com.muhammadiyah.storyapp

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.muhammadiyah.storyapp.databinding.ActivityMainBinding
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val storyViewModel: StoryViewModel by viewModels {
        ViewModelFactory(Injection.provideRepository(this))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val storyAdapter = StoryAdapter()
        binding.rvStories.apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            adapter = storyAdapter
        }

        val pref = UserPreference.getInstance(applicationContext)
        val user = runBlocking { pref.getUser().first() }
        Log.d("LoginActivity", "Token: ${user.token}")

        if (user.token.isNotEmpty()) {
            storyViewModel.getStories("Bearer ${user.token}")
        } else {
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
        }

        storyViewModel.stories.observe(this) { stories ->
            if (!stories.isNullOrEmpty()) {
                storyAdapter.submitList(stories)
            } else {
                Toast.makeText(this, "Tidak ada cerita ditemukan.", Toast.LENGTH_SHORT).show()
            }
        }

        storyViewModel.errorMessage.observe(this) { errorMessage ->
            Toast.makeText(this, errorMessage, Toast.LENGTH_SHORT).show()
        }
    }
}
