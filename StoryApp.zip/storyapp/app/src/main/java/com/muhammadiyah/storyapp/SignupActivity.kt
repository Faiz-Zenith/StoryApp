package com.muhammadiyah.storyapp

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import com.muhammadiyah.api.ApiConfig
import com.muhammadiyah.storyapp.databinding.ActivitySignupBinding

class SignupActivity : AppCompatActivity() {
    private lateinit var binding: ActivitySignupBinding
    private lateinit var viewModel: SignupViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySignupBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val userPreference = UserPreference.getInstance(applicationContext)
        val repository = StoryRepository(ApiConfig.getApiService(), userPreference) // Panggil dengan userPreference
        viewModel = ViewModelProvider(this, ViewModelFactory(repository))[SignupViewModel::class.java]

        viewModel.signupResult.observe(this) { message ->
            Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
            val intent = Intent(this, LoginActivity::class.java)
            startActivity(intent)
        }

        viewModel.errorMessage.observe(this) { error ->
            Toast.makeText(this, error, Toast.LENGTH_SHORT).show()
        }

        binding.buttonSignup.setOnClickListener {
            val name = binding.edRegisterName.text.toString()
            val email = binding.edRegisterEmail.text.toString()
            val password = binding.edRegisterPassword.getText().toString()
            if (name.isNotEmpty() && email.isNotEmpty() && password.length >= 8) {
                viewModel.signup(name, email, password)
            } else {
                Toast.makeText(this, "Isi semua field dengan benar", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
