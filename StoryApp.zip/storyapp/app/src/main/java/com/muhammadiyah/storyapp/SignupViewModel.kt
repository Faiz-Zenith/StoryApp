package com.muhammadiyah.storyapp

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.launch

class SignupViewModel(private val repository: StoryRepository) : ViewModel() {
    private val _signupResult = MutableLiveData<String>()
    val signupResult: LiveData<String> = _signupResult

    private val _errorMessage = MutableLiveData<String>()
    val errorMessage: LiveData<String> = _errorMessage

    fun signup(name: String, email: String, password: String) {
        viewModelScope.launch {
            try {
                val response = repository.signup(name, email, password)
                if (response.error == false) {
                    _signupResult.postValue(response.message ?: "Signup berhasil")
                } else {
                    _errorMessage.postValue(response.message ?: "Signup gagal")
                }
            } catch (e: Exception) {
                _errorMessage.postValue(e.message ?: "Terjadi kesalahan")
            }
        }
    }
}
