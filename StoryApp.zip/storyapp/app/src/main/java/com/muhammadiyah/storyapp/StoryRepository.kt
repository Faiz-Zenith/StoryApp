package com.muhammadiyah.storyapp

import android.util.Log
import com.muhammadiyah.api.ApiService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext

class StoryRepository(private val apiService: ApiService, private val userPreference: UserPreference) {
    suspend fun login(email: String, password: String): LoginResponse {
        return apiService.login(email, password)
    }

    suspend fun signup(name: String, email: String, password: String): RegisterResponse {
        return apiService.register(name, email, password)
    }

    suspend fun getStories(token: String): List<ListStoryItem> {
        val token = userPreference.getUser().first().token ?: return emptyList()
        return withContext(Dispatchers.IO) {
            try {
                val response = apiService.getStories(token)
                if (response.error == false) {
                    Log.d("StoryRepository", "Fetched ${response.listStory?.size ?: 0} stories.")
                    response.listStory?.filterNotNull() ?: emptyList()
                } else {
                    Log.e("StoryRepository", "Error: ${response.message}")
                    emptyList()
                }
            } catch (e: Exception) {
                Log.e("StoryRepository", "Exception: ${e.message}")
                emptyList()
            }
        }
    }

    companion object {
        @Volatile
        private var instance: StoryRepository? = null

        fun getInstance(apiService: ApiService, userPreference: UserPreference): StoryRepository =
            instance ?: synchronized(this) {
                instance ?: StoryRepository(apiService, userPreference).also { instance = it }
            }
    }
}
