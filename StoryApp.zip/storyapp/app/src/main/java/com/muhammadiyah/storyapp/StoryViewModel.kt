package com.muhammadiyah.storyapp

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.launch

class StoryViewModel(private val storyRepository: StoryRepository) : ViewModel() {
    private val _stories = MutableLiveData<List<ListStoryItem>>()
    val stories: LiveData<List<ListStoryItem>> = _stories

    private val _errorMessage = MutableLiveData<String>()
    val errorMessage: LiveData<String> = _errorMessage

    fun getStories(token: String) {
        viewModelScope.launch {
            try {
                val response = storyRepository.getStories(token)
                if (response.isNotEmpty()) {
                    _stories.postValue(response)
                    Log.d("StoryViewModel", "Stories fetched: ${response.size}")
                } else {
                    _stories.postValue(emptyList())
                    _errorMessage.postValue("Tidak ada cerita ditemukan.") // Update error message
                    Log.e("StoryViewModel", "No stories found.")
                }
            } catch (e: Exception) {
                _stories.postValue(emptyList())
                _errorMessage.postValue("Terjadi kesalahan: ${e.message}") // Update error message
                Log.e("StoryViewModel", "Error fetching stories: ${e.message}")
            }
        }
    }
}
