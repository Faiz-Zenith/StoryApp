package com.muhammadiyah.storyapp

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "user_prefs")

class UserPreference private constructor(private val dataStore: DataStore<Preferences>) {

    private val tokenKey = stringPreferencesKey("token")

    fun getUser(): Flow<User> {
        return dataStore.data.map { preferences ->
            User(
                token = preferences[tokenKey] ?: ""
            )
        }
    }

    suspend fun saveUser(user: User) {
        dataStore.edit { preferences ->
            preferences[tokenKey] = user.token
        }
    }

    companion object {
        @Volatile
        private var instance: UserPreference? = null

        fun getInstance(context: Context): UserPreference {
            return instance ?: synchronized(this) {
                instance ?: UserPreference(context.dataStore).also { instance = it }
            }
        }
    }
}

data class User(val token: String)
